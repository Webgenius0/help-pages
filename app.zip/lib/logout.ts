/**
 * Logout utility function
 * 
 * Handles logout with proper redirect URL that preserves subdomain
 */

import { signOut } from "next-auth/react";

/**
 * Sign out the user and redirect to login page on the same domain/subdomain
 */
export function handleLogout() {
  // Get current hostname and protocol to preserve subdomain
  if (typeof window !== "undefined") {
    const hostname = window.location.hostname;
    const protocol = window.location.protocol;
    const loginUrl = `${protocol}//${hostname}/auth/login`;
    
    // Sign out with callback URL to preserve subdomain
    signOut({ 
      callbackUrl: loginUrl,
      redirect: true 
    });
  } else {
    // Fallback for server-side (shouldn't happen, but just in case)
    signOut({ callbackUrl: "/auth/login" });
  }
}

