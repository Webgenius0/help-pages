// Type definitions for the project
